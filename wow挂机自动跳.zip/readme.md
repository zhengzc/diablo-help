# 辅助插件说明

# 需要安装java运行时环境
* 去https://www.java.com/zh_CN/download/下载并安装

## 如何使用
* 首先点击*.bat启动对应程序，程序将在命令行运行。
* 切换到游戏界面。
* 使用ctrl+F1即可启动程序。
* 使用ctrl+F2即可停止程序。

## 常见问题
* 如果报错需要将JIntellitype.dll两个文件放入windows目录下。